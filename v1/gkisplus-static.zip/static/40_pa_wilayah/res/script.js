// Example JavaScript code
console.log("Hello, World!");
document.getElementById("clickable").onclick = function() {
    document.getElementById("clickable-action").innerHTML = "You just clicked the dummy button."
};
